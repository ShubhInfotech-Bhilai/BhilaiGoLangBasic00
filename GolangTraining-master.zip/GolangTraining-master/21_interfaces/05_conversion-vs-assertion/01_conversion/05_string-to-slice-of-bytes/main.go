package main

import "fmt"

func main() {
	fmt.Println([]byte("hello"))
	// conversion: string to []bytes
	// we'll learn about []bytes soon
}
