package main

import "fmt"

func main() {
	var name = "Todd"
	fmt.Println("Hello ", name)
}
