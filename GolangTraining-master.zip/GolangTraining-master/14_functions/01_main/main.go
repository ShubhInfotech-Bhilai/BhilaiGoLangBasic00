package main

import "fmt"

func main() {
	fmt.Println("Hello world!")
}

// main is the entry point to your program
