package main

import "fmt"

func main() {
	fmt.Printf("%d - %b \n", 42, 42)
}
