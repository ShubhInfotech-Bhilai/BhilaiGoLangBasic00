package hello

import "fmt"

func Hello() {
	fmt.Println("Hello")
}
