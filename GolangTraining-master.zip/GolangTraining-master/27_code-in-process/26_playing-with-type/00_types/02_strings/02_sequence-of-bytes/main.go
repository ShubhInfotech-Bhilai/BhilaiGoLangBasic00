package main

import "fmt"

func main() {
	intro := "Four score and seven years ago...."
	fmt.Println(intro)
	fmt.Println([]byte(intro)) // sequence of bytes
}
