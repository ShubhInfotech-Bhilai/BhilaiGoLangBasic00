package main

import "fmt"

func main() {
	fmt.Println("Hello\tWorld\nHow are you?")
}
