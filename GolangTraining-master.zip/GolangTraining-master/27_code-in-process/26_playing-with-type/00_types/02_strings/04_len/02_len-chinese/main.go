package main

import "fmt"

func main() {
	fmt.Println(len("世界"))
}
