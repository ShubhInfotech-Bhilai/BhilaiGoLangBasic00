package main

import "fmt"

func main() {
	greeting := "Hello"
	fmt.Println(greeting)
	fmt.Println(greeting[0])
	fmt.Println(greeting[4])
	fmt.Println("-------------")
	fmt.Println("What the ... ")
	fmt.Println(greeting[:4])
	fmt.Println("... did that just do?")
}
